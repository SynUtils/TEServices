/**
 * Copyright 2014 Google Inc. All Rights Reserved.
 *
 * @fileoverview Interaction tests for Hide and Unhide multiple slides. The test
 * data contains alternate hidden slides. These tests are performed in following
 * steps,
 * 1. Select few slides using shift key i.e. Click on desired starting slide >
 *    Press shift key > click on desired end slide
 * 2. Hide the slides
 * 3. Verify that all the selected slides are hidden
 * 4. Unhide the slides
 * 5. Verify that all the selected slides are un-hidden
 *
 * These tests are carried out for below use cases,
 * 1. Using shortcut keys i.e. CMD+H for Hide and CMD+U for unhide
 * 2. Using Main Menubar menu options for Hide and Unhide
 * 3. Using Thumbnail Context menu options for Hide and Unhide
 *
 * @author wasim.pathan@synerzip.com (Wasim Pathan)
 */

define([
  'http://localhost:9876/client/tester.js',
  'qowtRoot/interactiontests/waitHelper',
  'qowtRoot/unittests/utils/fakeEvents',
  'qowtRoot/utils/mockKeyboard/keyboard',
  'qowtRoot/utils/mockKeyboard/keys',
  'qowtRoot/widgets/point/thumbnailContextMenu',
  'qowtRoot/widgets/point/thumbnailStrip',
  'qowtRoot/widgets/ui/mainToolbar'

], function(
    Tester,
    WaitFor,
    FakeEvents,
    Keyboard,
    keys,
    ThumbnailContextMenu,
    ThumbnailStrip,
    MainToolbar) {

  'use strict';

  Tester.register({

    name: 'Multiple Slides hide unhide tests',

    // start tests when all the content is loaded
    signal: 'qowt:contentComplete',

    matches: ['**/point/slide/hiddenSlides.ppt*'],

    spec: function() {

      describe('Hide and unhide slides', function() {

        var startSlideIndex, endSlideIndex;

        beforeEach(function() {
          // Wait till thumbnailStrip tool to be active so we can play our
          // changes.
          WaitFor.thumbnailStripToolActive();
        });

        it('should hide/unhide the slides using shortcut keys', function() {
          startSlideIndex = 0;
          endSlideIndex = 1;
          selectSlides(startSlideIndex, endSlideIndex);
          hitShortcutKeys('H');
          verifyResult(startSlideIndex, endSlideIndex, true);
          hitShortcutKeys('U');
          verifyResult(startSlideIndex, endSlideIndex, false);
        });

        it('should hide/unhide the slides using main menubar', function() {
          startSlideIndex = 2;
          endSlideIndex = 3;
          var slideMenuWidget = MainToolbar.getItem('menu-slide');
          var hideButtonNode = slideMenuWidget.
              getMenuItemNode('menuitem-hideSld');
          var unHideButtonNode = slideMenuWidget.
              getMenuItemNode('menuitem-showSld');
          selectSlides(startSlideIndex, endSlideIndex);
          simulateMenuClick(hideButtonNode);
          verifyResult(startSlideIndex, endSlideIndex, true);
          simulateMenuClick(unHideButtonNode);
          verifyResult(startSlideIndex, endSlideIndex, false);
        });

        it('should hide/unhide the slides using context menu', function() {
          startSlideIndex = 4;
          endSlideIndex = 5;
          var hideSlideContextMenuNode = ThumbnailContextMenu.
              getContextMenuItemNode('menuitem-hideSld');
          var unHideSlideContextMenuNode = ThumbnailContextMenu.
              getContextMenuItemNode('menuitem-showSld');
          selectSlides(startSlideIndex, endSlideIndex);
          simulateMenuClick(hideSlideContextMenuNode);
          verifyResult(startSlideIndex, endSlideIndex, true);
          simulateMenuClick(unHideSlideContextMenuNode);
          verifyResult(startSlideIndex, endSlideIndex, false);
        });
      });
    }
  });

  /**
   * Selects all the slides between given indices (both inclusive)
   * @param {int} startSlideIndex - Index of slide to start selection
   * @param {int} endSlideIndex - Index of slide to end selection
   * @private
   */
  function selectSlides(startSlideIndex, endSlideIndex) {
    simulateSlideClick(startSlideIndex, false);
    simulateSlideClick(endSlideIndex, true);
  }

  /**
   * Simulates the mouse click event on slide node
   * @param {int} slideIndex - index of the slide to be clicked(starting from 0)
   * @param {boolean} isShiftKey - shift key state, true if shift key is to be
   *                               pressed, otherwise false.
   * @private
   */
  function simulateSlideClick(slideIndex, isShiftKey) {
    WaitFor.runsAndSignal(
        function() {
          var slide = ThumbnailStrip.thumbnail(slideIndex);
          FakeEvents.simulate(slide.node(), 'click', {shiftKey: isShiftKey});
        },
        'qowt:selectionChanged:toolbarDone'
    );
  }

  /**
   * This method simulates shortcut key press actions for Hide/Unhide.
   * @param {String} keyChar - Character 'H' to form CMD+H to hide the slide and
   *                           'U' to form CMD+U to unhide the slide
   * @private
   */
  function hitShortcutKeys(keyChar) {
    WaitFor.runsAndSignal(
        function() {
          Keyboard.type(keys('meta', keyChar));
        },
        'qowt:cmdshowSldStop'
    );
  }

  /**
   * This method simulates click on Menu buttons(from menubar as well as
   * thumbnail context menu) for Hide/Unhide.
   * @param {HTMLElement} menuItemNode - DOM element of menuItem corresponding
   *                                     to Hide and Unhide menu options from
   *                                     Menubar OR thumbnail context menu
   * @private
   */
  function simulateMenuClick(menuItemNode) {
    WaitFor.runsAndSignal(
        function() {
          FakeEvents.simulate(menuItemNode, 'click');
        },
        'qowt:cmdshowSldStop'
    );
  }

  /**
   * Verifies the hidden state of all the slides between given indices (both
   * inclusive)
   * @param {int} startSlideIndex - Index of slide from where selection started
   * @param {int} endSlideIndex - Index of slide to end of selection
   * @param {boolean} hide - Expected hidden state. true for hide and false for
   *                         unhide
   * @private
   */
  function verifyResult(startSlideIndex, endSlideIndex, hide) {
    runs(function() {
      for (var i = startSlideIndex; i <= endSlideIndex; i++) {
        expect(ThumbnailStrip.thumbnail(i).isHidden()).toBe(hide);
      }
    });
  }
});
