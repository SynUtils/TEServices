/**
 * Copyright 2014 Google Inc. All Rights Reserved.
 *
 * @fileoverview Interaction tests for Hide and Unhide slides. The test data
 * contains alternate hidden slides. These tests are performed on each slide
 * where non-hidden slides are made hidden and vice versa.
 *
 * These tests are carried out for below use cases,
 * 1. Using shortcut keys i.e. CMD+H for Hide and CMD+U for unhide
 * 2. Using Main Menubar menu options for Hide and Unhide
 * 3. Using Thumbnail Context menu options for Hide and Unhide
 *
 * @author wasim.pathan@synerzip.com (Wasim Pathan)
 */

define([
  'http://localhost:9876/client/tester.js',
  'qowtRoot/interactiontests/waitHelper',
  'qowtRoot/unittests/utils/fakeEvents',
  'qowtRoot/utils/mockKeyboard/keyboard',
  'qowtRoot/utils/mockKeyboard/keys',
  'qowtRoot/widgets/point/thumbnailContextMenu',
  'qowtRoot/widgets/point/thumbnailStrip',
  'qowtRoot/widgets/ui/mainToolbar'

], function(
    Tester,
    WaitFor,
    FakeEvents,
    Keyboard,
    keys,
    ThumbnailContextMenu,
    ThumbnailStrip,
    MainToolbar) {

  'use strict';

  Tester.register({

    name: 'Slide hide unhide tests',

    // start tests when all the content is loaded
    signal: 'qowt:contentComplete',

    matches: ['**/point/slide/hiddenSlides.ppt*'],

    spec: function() {

      describe('Hide and unhide slides', function() {

        beforeEach(function() {
          // Wait till thumbnailStrip tool to be active so we can play our
          // changes.
          WaitFor.thumbnailStripToolActive();
        });

        it('should hide the slide using shortcut keys', function() {
          hitShortcutKeysAndVerify(0, true, 'H');
        });

        it('should unhide the slide using shortcut keys', function() {
          hitShortcutKeysAndVerify(1, false, 'U');
        });

        it('should hide the slide using main menubar', function() {
          var slideMenuWidget = MainToolbar.getItem('menu-slide');
          var hideButtonNode = slideMenuWidget.
              getMenuItemNode('menuitem-hideSld');
          clickMenuAndVerify(2, true, hideButtonNode);
        });

        it('should unhide the slide using main menubar', function() {
          var slideMenuWidget = MainToolbar.getItem('menu-slide');
          var unHideButtonNode = slideMenuWidget.
              getMenuItemNode('menuitem-showSld');
          clickMenuAndVerify(3, false, unHideButtonNode);
        });

        it('should hide the slide using thumbnail context menu', function() {
          var hideSlideContextMenuNode = ThumbnailContextMenu.
              getContextMenuItemNode('menuitem-hideSld');
          clickMenuAndVerify(4, true, hideSlideContextMenuNode);
        });

        it('should unhide the slide using thumbnail context menu', function() {
          var unHideSlideContextMenuNode = ThumbnailContextMenu.
              getContextMenuItemNode('menuitem-showSld');
          clickMenuAndVerify(5, false, unHideSlideContextMenuNode);
        });
      });
    }
  });

  /**
   * This method simulates shortcut key press actions for Hide/Unhide and
   * verifies the result.
   * @param {number} slideIndex - Index of slide within thumbnailstrip starting
   *                              from 0
   * @param {boolean} hide - Action to be taken, true to hide the slide and
   *                         false to unhide the slide
   * @param {char} keyChar - Character 'H' to form CMD+H to hide the slide and
   *                         'U' to form CMD+U to unhide the slide
   * @private
   */
  function hitShortcutKeysAndVerify(slideIndex, hide, keyChar) {
    var slideWidget = ThumbnailStrip.thumbnail(slideIndex);
    expect(slideWidget.isHidden()).toBe(!hide);
    WaitFor.runsAndSignal(
        function() {
          FakeEvents.simulate(slideWidget.node(), 'click');
          Keyboard.type(keys('meta', keyChar));
        },
        'qowt:cmdshowSldStop'
    );
    runs(function() {
      expect(slideWidget.isHidden()).toBe(hide);
    });
  }

  /**
   * This method simulates click on Menu buttons(from menubar as well as
   * thumbnail context menu) for Hide/Unhide and verifies the result.
   * @param {number} slideIndex - Index of slide within thumbnailstrip starting
   *                              from 0
   * @param {boolean} hide - Action to be taken, true to hide the slide and
   *                         false to unhide the slide
   * @param {HTMLElement} menuItemNode - DOM element of menuItem corresponding
   *                                     to Hide and Unhide menu options from
   *                                     Menubar OR thumbnail context menu
   * @private
   */
  function clickMenuAndVerify(slideIndex, hide, menuItemNode) {
    var slideWidget = ThumbnailStrip.thumbnail(slideIndex);
    expect(slideWidget.isHidden()).toBe(!hide);
    WaitFor.runsAndSignal(
        function() {
          FakeEvents.simulate(slideWidget.node(), 'click');
          FakeEvents.simulate(menuItemNode, 'click');
        },
        'qowt:cmdshowSldStop'
    );
    runs(function() {
      expect(slideWidget.isHidden()).toBe(hide);
    });
  }
});
