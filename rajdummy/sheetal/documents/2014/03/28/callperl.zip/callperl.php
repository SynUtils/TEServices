<html>
<body>
<?php
$FileType = $_REQUEST["c1"];
$Selected_Feature =$_REQUEST["c2"];
$FileCount = $_REQUEST["c3"];
$CheckRandom=$_REQUEST["c4"];
$datet=$_REQUEST["c5"];
$content = $FileType.$Selected_Feature.$FileCount.$CheckRandom.$datet;
$fp = fopen("D:\\val.txt","wb");
fwrite($fp,$content);
fclose($fp);
if($FileType==1)
{$FileType="doc";
}
else if($FileType==2)
{
$FileType="docx";
}
else if($FileType==3)
{
$FileType="xls";
}
else if($FileType==4)
{
$FileType="xlsx";
}
else if($FileType==5)
{
$FileType="ppt";
}
else if($FileType==6)
{
$FileType="pptx";
}
if($CheckRandom=="default")
{  
   system("perl C:\\wamp\\www\\Final\\Zip\\all_in_one.pl $Selected_Feature $FileType $FileCount $datet" );
   //  echo "<br >PPTX Files extract to \\172.24.212.56\\E:\\$Selected_Feature <br >";
}
else	
{
     system("perl C:\\wamp\\www\\Final\\Zip\\all_in_one.pl $Selected_Feature $FileType $FileCount $datet $CheckRandom" );
   //  echo "<br >PPTX Files extract to \\172.24.212.56\\E:\\$Selected_Feature <br >";
}
?>
		
</body>
</html>