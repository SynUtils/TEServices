<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" dir="ltr" lang="en">
<head>
<title>Files Download</title>
<script language="javascript">
	var arr = new Array();
	arr[0] = new Array("-select-");
	arr[1] = new Array("-select-","Paragraphs","Sentences","Words","Characters","Sections","Fields","Fields_IncludePicture","Fields_Sequence","Fields_Embed","Fields_Formula","Fields_TOCEntry",
						"Fields_DocInfo","Fields_UserInfo","Endnotes","Footnotes","FormFields","Bookmarks","Headers","Footers","Comments","CustomXmlParts","Hyperlinks","Lists","Shapes",
						"Shapes_Picture","Shapes_AutoShape","Shapes_Line","Shapes_TextBox","Shapes_Group","Shapes_Callout","Shapes_Diagram","Shapes_TextEffect","InlineShapes","InlineShapes_Picture","InlineShapes_LinkedPicture","InlineShapes_EmbeddedOLEObject","InlineShapes_HorizontalLine","InlineShapes_PictureBullet","Styles","Tables","TOC","Indexes");
	arr[2] = new Array("-select-","Paragraphs","Sentences","Words","Characters","Sections","Fields","Fields_IncludePicture","Fields_Sequence","Fields_Embed","Fields_Formula","Fields_TOCEntry",
						"Fields_DocInfo","Fields_UserInfo","Endnotes","Footnotes","FormFields","Bookmarks","Headers","Footers","Comments","CustomXmlParts","Hyperlinks","Lists","Shapes",
						"Shapes_Picture","Shapes_AutoShape","Shapes_Line","Shapes_TextBox","Shapes_Group","Shapes_Callout","Shapes_Diagram","Shapes_ShapeTypeMixed","Shapes_TextEffect",
						"Shapes_SmartArt","InlineShapes","InlineShapes_Picture","InlineShapes_LinkedPicture","InlineShapes_EmbeddedOLEObject","InlineShapes_Chart","InlineShapes_HorizontalLine",
						"InlineShapes_SmartArt","InlineShapes_PictureBullet","Styles","Tables","TOC","Indexes");
	
	arr[3] = new Array("-select-","SmartArt","Charts","SortedFields","Comments","Filters","Images_Png_Gif","Shapes","Styles","Embedded_Objects","Sheet_Table","Hyperlink","Images_EMF_WMF","MergeCells",
					   "Pivot_Table","Protected_Sheet","Forms_Fields","ActiveX","FrozenPanes","Conditional_Formatting","WrapText","Format_Cell_Fill_Pattern_Style","Format_Cell_Fill_Background_Colour",
					   "Text_Horizontal_Left_Align","Text_Horizontal_Right_Align","Text_Horizontal_Centre_Align","Text_Vertical_Top_Align","Text_Vertical_Bottom_Align","Text_Vertical_Centre_Align",
					   "Formula","PercentageFormat","NumberFormat","CurrencyFormat","DateFormat");
	arr[4] = new Array("-select-","SmartArt","Charts","SortedFields","Comments","Filters","Images_Png_Gif","Shapes","Styles","Embedded_Objects","Sheet_Table","Hyperlink","Images_EMF_WMF","MergeCells",	
					   "Pivot_Table","Protected_Sheet","Forms_Fields","ActiveX","FrozenPanes","Conditional_Formatting","WrapText","Format_Cell_Fill_Pattern_Style","Format_Cell_Fill_Background_Colour",
					   "Text_Horizontal_Left_Align","Text_Horizontal_Right_Align","Text_Horizontal_Centre_Align","Text_Vertical_Top_Align","Text_Vertical_Bottom_Align","Text_Vertical_Centre_Align",
					   "Formula","PercentageFormat","NumberFormat","CurrencyFormat","DateFormat","file_2007","file_2010","file_2013","Other_office");
					
	arr[5] = new Array("-select-","Animations","Embedded_Objects","Embedded_Objects_Charts","Headers_Footers","Hyperlinks","Images_EMF_WMF","Images_PNG_GIF_JPG",
					  "Shapes","Shapes_3D_Effects","Shapes_Fills","Shapes_Freeform","Shapes_Other_Effects","Slide_Backgrounds","SmartArt","Speaker_Notes","Tables","Text_Box","Themes","Transitions",
					  "Lists_Numeric","Fonts","Lists_Character","Lists_Picture");				
	arr[6] = new Array("-select-","Animations","Comments","Embedded_Objects","Embedded_Objects_Charts","Headers_Footers","Hyperlinks","Images_EMF_WMF","Images_PNG_GIF_JPG",
					  "Shapes","Shapes_3D_Effects","Shapes_Fills","Shapes_Freeform","Shapes_Other_Effects","Slide_Backgrounds","SmartArt","Speaker_Notes","Tables","Text_Box","Themes","Transitions","Lists_Numeric","Fonts","Lists_Character","Lists_Picture");
	function change(combo1)
	{
		var comboValue=combo1.value;
		document.forms["ajax"].elements["combo2"].options.length=0;
	for (var i=0;i<arr[comboValue].length;i++)
		{
		 var option = document.createElement("option");
		 option.innerHTML = arr[comboValue][i];
		 document.forms["ajax"].elements["combo2"].appendChild(option);
		}
	}
</script>
<script src="ajax.js" type="text/javascript"></script>
<script language="JavaScript">
var  filetype;
var SelectedFeature ;
var FileCount ;
var checkrandom;
var flag;
var datetime;
 function Write(url, content)	// url is the script and data is a string of parameters
	{ 
	 var sbmt = document.getElementById("btnsbt");
		var xhr = createXHR();
		 xhr.onreadystatechange=function()
        {
         if (xhr.readyState==4 && xhr.status==200)
         {
		 sbmt.disabled = false;
		 var storing = document.getElementById("storage");
	     storing.innerHTML = "<p>Click here to download Files<b><a href='#' id='getdownload' onClick='DownloadFile()'>"+SelectedFeature+"_"+datetime+"</a></b>.";
         document.getElementById("img").innerHTML="";
		 document.getElementById("subtn").innerHTML="";
         document.getElementById("image").src = "";
		 
	     flag="false";
         }
		else
		 {
		  if(flag=="true")
		   {
             sbmt.disabled = true;
    		 document.getElementById("img").innerHTML="Processing The Files...";
	        document.getElementById("image").src = "1.gif";
			
			}
		}
       }
	  //alert(url+content);	
	   xhr.open("GET", url+content, true);		
	  xhr.send(); 
	} 
	/*
function doesFileExist(urlToFile)
{
    var xhr = new XMLHttpRequest();
    xhr.open('HEAD', urlToFile, false);
    xhr.send();
     
    if (xhr.status == "404") {
        return false;
    } else {
        return true;
    }
}
var result = doesFileExist("c:\\wamp\\www\\Final\\FeatureFileDownloder\\"+SelectedFeature+".zip");
    if(result == false) {
      alert("file does not exist!");
   }
	*/
	function DownloadFile()
  {
    
   var hrefpath="Final/Zip/" + SelectedFeature+"_"+datetime+".zip";
    getdownload.href =hrefpath;
	var filepath= SelectedFeature+"_"+datetime+".zip";
     getdownload.download =filepath;
	 
  }
    function isNumberKey(evt)
       {
          var charCode = (evt.which) ? evt.which : event.keyCode;
          if (charCode != 46 && charCode > 31 
            && (charCode < 48 || charCode > 57))
             return false;

          return true;
       }
function submitForm()
 { 
    var currentdate = new Date(); 
     datetime = "" + currentdate.getDate() + ""+ (currentdate.getMonth()+1)+ ""+ currentdate.getFullYear() + ""+ currentdate.getHours() +""+ currentdate.getMinutes() + "" + currentdate.getSeconds();
	//alert(datetime);
	 flag="true";
	var queryString="";
	filetype = document.getElementById('comb1').value;
	SelectedFeature = document.getElementById('comb2').value;
	FileCount = document.getElementById('filecnt').value;
	checkrandom = document.getElementsByName('random');
	//Validation For All Tools
	if (filetype=="0")
	{
        alert("Please Select FileType");
        return false;
	}
	if (SelectedFeature=="-select-")
	{
        alert("Please Select Feature");
        return false;
	}
	/*if (FileCount>1000)
		{
        alert("File count should be less than 1000...");
        return false;
		}*/
		if (FileCount<=0)
		{
        alert("File Count should not be zero and Blank... ");
        return false;
		}
	for (var i = 0, length = checkrandom.length; i < length; i++) {
        if (checkrandom[0].checked)
		{
               queryString = "?c1=" + filetype+"&c2=" + SelectedFeature + "&c3=" +FileCount+"&c4=random"+"&c5="+datetime;   			   
         }
		 if(checkrandom[1].checked)
		{
          queryString = "?c1=" + filetype+"&c2=" + SelectedFeature + "&c3=" +FileCount+"&c4=default"+"&c5="+datetime;  
        }
     }
	Write("callperl.php", queryString);	   
 } 
</script>
</head>
<h3 align="center"> Feature Extraction Tool</h3>
<p>
<p>
<p>
<hr>
<div id="img" align='center'>
   <h2 id="pid" align="center"></h2>
   <br>
   <br>
   <img id="image" align="center" src="#" style="display: none;">
</div>
<FORM name="ajax" method="" action="">
<table border="1" style="width:25%;" align="center" >
	<tr>
		<th  style="width:20%;">Criteria </th>
		<th  style="width:20%;">Values</th>
	</tr>
	<tr>
		<th  style="width:20%;">File Type:</th>
		<td><select name="combo1" id="comb1" onchange="change(this);">
			<option value="0">-Select-</option>
			<option value="1">doc</option>
			<option value="2">docx</option>
			<option value="3">xls</option>
			<option value="4">xlsx</option>
			<option value="5">ppt</option>	
			<option value="6">pptx</option>
			</select>
		</td>
	</tr>
	<tr>
		<th style="width:20%;">Feature:</th>
		<td><select name="combo2" id="comb2"></select> 
		</td>
	</tr>
	<tr>
		<th rowspan="2" style="width:20%;">Random Selection:</th>
		<td><input type="radio" name="random"id="On" value="1" >ON
	</tr>
	<tr>
		<td><input type="radio" name="random" id="Off"value="0" checked >OFF </td>
	</tr>
	<tr>
		<th  style="width:20%;">File Count:</th>
		<td><input type="text" id="filecnt" name="fileCount" onkeypress="return isNumberKey(event)"maxlength="4" > </td>
	</tr>
	<tr>
		<th colspan="2"><INPUT type="button" name="subtn" id="btnsbt" value="Submit"  ONCLICK="submitForm()" ></th>
	</tr>
</table>
<br>

</FORM>
<div id="storage"></div>
</body>
</html>
